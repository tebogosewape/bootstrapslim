<?php namespace App\Classes ;

	class Helpers {

	}