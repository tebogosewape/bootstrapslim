<?php 

	require "bootstrap/app.php" ;

	$app->run() ;