<?php

	return [
		
		'host' 				=> 'smtp.gmail.com',
		'debug' 			=> 1,
		'port' 				=> 587,
		'secure' 			=> 'tls',
		'auth' 				=> true,
		'username' 			=> 'milkandhoney20180505@gmail.com',
		'password' 			=> '450411@tjS',

	] ;