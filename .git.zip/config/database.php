<?php

	return [
		
			'db'					=> [

				'driver'			=> 'mysql',
				'host'				=> 'localhost',
				'database'			=> 'milk_and_honey_db',
				'username'			=> 'root',
				'password'			=> '450411@tjS',
				'charset'			=> 'utf8',
				'collation'			=> 'utf8_unicode_ci',
				'prefix' 			=> '',

			],

	] ;