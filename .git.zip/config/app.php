<?php

	return [
		
		'app_name' 				=> "Slim Boilerplate",
		'displayErrorDetails' 	=> true,

	] ;